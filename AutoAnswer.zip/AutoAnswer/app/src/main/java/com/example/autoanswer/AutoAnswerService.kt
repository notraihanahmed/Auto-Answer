package com.example.autoanswer

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.TextView
import android.widget.Toast
import kotlin.concurrent.thread
import kotlin.math.abs

class AutoAnswerService : AccessibilityService() {
    companion object {
        @Volatile var enabled = false
        var instance: AutoAnswerService? = null
    }

    // Buttons with these words are tapped directly (no AI call needed)
    private val again = Regex("play again|try again|play more|replay|restart|retry|new game|start again", RegexOption.IGNORE_CASE)
    private val handler = Handler(Looper.getMainLooper())
    private val loop = object : Runnable {
        override fun run() { if (enabled) { tick(); handler.postDelayed(this, 1000) } }
    }
    private var busy = false
    private var lastHash = 0
    private var lastAskAt = 0L
    private var nextScanAt = 0L
    private var overlay: TextView? = null

    override fun onServiceConnected() { instance = this }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onDestroy() { hideOverlay(); instance = null; super.onDestroy() }

    // ---- Main loop: read screen -> (Play again | ask AI) -> tap -> repeat ----
    private fun tick() {
        val now = SystemClock.uptimeMillis()
        if (busy || now < nextScanAt) return
        val root = rootInActiveWindow ?: return
        if (root.packageName == packageName) return          // don't act on our own app
        val opts = mutableListOf<AccessibilityNodeInfo>()
        val sb = StringBuilder()
        walk(root, opts, sb)
        if (opts.size < 2 && opts.none { again.containsMatchIn(label(it)) }) {
            opts.clear(); sb.clear(); walkLeaves(root, opts, sb)   // fallback: numbered text items
        }

        opts.firstOrNull { again.containsMatchIn(label(it)) }?.let {
            toast("Tapping: ${label(it)}")
            click(it)
            lastHash = 0
            nextScanAt = now + 2500
            return
        }

        val screen = sb.toString()
        val h = screen.replace(Regex("\\d+"), "#").hashCode()   // ignore timers/scores
        if (h == lastHash && now - lastAskAt < 5000) return
        lastHash = h; lastAskAt = now
        if (opts.size < 2) { toast("No answer options found on this screen"); return }

        val p = getSharedPreferences("p", MODE_PRIVATE)
        busy = true
        thread {
            val r = Ai.ask(p.getString("key", "") ?: "", p.getString("model", "") ?: "", screen)
            handler.post {
                busy = false
                val n = r.n
                val t = SystemClock.uptimeMillis()
                when {
                    !enabled -> {}
                    n == null -> {
                        toast("AI error: ${r.error}")
                        nextScanAt = t + if (r.error?.contains("429") == true) 20000 else 3000
                    }
                    n !in 1..opts.size -> toast("AI: nothing to tap")
                    else -> {
                        toast("Tapped $n: ${label(opts[n - 1])}")
                        opts[n - 1].refresh()
                        click(opts[n - 1])
                        nextScanAt = t + 1800
                    }
                }
            }
        }
    }

    private fun walk(n: AccessibilityNodeInfo, opts: MutableList<AccessibilityNodeInfo>, sb: StringBuilder) {
        if (!n.isVisibleToUser) return
        if (n.isClickable || n.isCheckable) {
            opts.add(n)
            sb.append("[${opts.size}] ").append(label(n)).append('\n')
            return
        }
        (n.text ?: n.contentDescription)?.takeIf { it.isNotBlank() }?.let { sb.append(it).append('\n') }
        for (i in 0 until n.childCount) n.getChild(i)?.let { walk(it, opts, sb) }
    }

    // Fallback for apps whose answers aren't marked clickable
    private fun walkLeaves(n: AccessibilityNodeInfo, opts: MutableList<AccessibilityNodeInfo>, sb: StringBuilder) {
        if (!n.isVisibleToUser) return
        if (n.childCount == 0) {
            val t = n.text ?: n.contentDescription
            if (!t.isNullOrBlank()) { opts.add(n); sb.append("[${opts.size}] ").append(t).append('\n') }
        }
        for (i in 0 until n.childCount) n.getChild(i)?.let { walkLeaves(it, opts, sb) }
    }

    private fun label(n: AccessibilityNodeInfo): String {
        val s = StringBuilder()
        (n.text ?: n.contentDescription)?.let { s.append(it).append(' ') }
        for (i in 0 until n.childCount) n.getChild(i)?.let { s.append(label(it)) }
        return s.toString().trim()
    }

    private fun click(n: AccessibilityNodeInfo) {
        if (n.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return
        val r = Rect().also { n.getBoundsInScreen(it) }       // fallback: real screen tap
        val path = Path().apply { moveTo(r.exactCenterX(), r.exactCenterY()) }
        val stroke = GestureDescription.StrokeDescription(path, 0, 50)
        dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), null, null)
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()

    // ---- Floating ON/OFF button (display over other apps) ----
    private fun paint(b: TextView) {
        b.text = if (enabled) "ON" else "OFF"
        b.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(if (enabled) Color.rgb(0, 160, 0) else Color.RED)
        }
    }

    fun showOverlay() {
        if (overlay != null || !Settings.canDrawOverlays(this)) return
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val size = (64 * resources.displayMetrics.density).toInt()
        val btn = TextView(this).apply {
            textSize = 14f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            minWidth = size; minHeight = size
        }
        paint(btn)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 0; y = 300 }

        var sx = 0; var sy = 0; var dx = 0f; var dy = 0f; var moved = false
        btn.setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; dx = e.rawX; dy = e.rawY; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val mx = (e.rawX - dx).toInt(); val my = (e.rawY - dy).toInt()
                    if (abs(mx) > 10 || abs(my) > 10) moved = true
                    lp.x = sx + mx; lp.y = sy + my
                    wm.updateViewLayout(v, lp)
                }
                MotionEvent.ACTION_UP -> if (!moved) {
                    enabled = !enabled
                    paint(btn)
                    handler.removeCallbacks(loop)
                    if (enabled) { lastHash = 0; nextScanAt = 0; handler.post(loop) }
                }
            }
            true
        }
        wm.addView(btn, lp)
        overlay = btn
    }

    fun hideOverlay() {
        enabled = false
        handler.removeCallbacks(loop)
        overlay?.let { try { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) } catch (e: Exception) {} }
        overlay = null
    }
}
