package com.example.autoanswer

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class Result(val n: Int?, val error: String? = null)

object Ai {
    private const val DEFAULT_MODEL = "gemini-3.8-flash"
    private const val SYSTEM =
        "You receive the text of a phone screen from a quiz/trivia game. Items marked [n] are tappable. " +
        "If the screen shows a question with answer options (usually four), reply with ONLY the number n of the correct option. " +
        "If the answer is already selected or revealed, or there is no question, and there is a Start/Play/Next/Continue/Play again button, " +
        "reply with that button's number. Otherwise reply 0. Never explain."

    fun ask(apiKey: String, model: String, screen: String): Result {
        if (apiKey.isBlank()) return Result(null, "No API key saved")
        return try {
            val m = model.ifBlank { DEFAULT_MODEL }
            val body = JSONObject()
                .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", SYSTEM))))
                .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", screen)))))
            val c = URL("https://generativelanguage.googleapis.com/v1beta/models/$m:generateContent")
                .openConnection() as HttpURLConnection
            c.requestMethod = "POST"
            c.doOutput = true
            c.connectTimeout = 15000
            c.readTimeout = 30000
            c.setRequestProperty("x-goog-api-key", apiKey)
            c.setRequestProperty("content-type", "application/json")
            c.outputStream.use { it.write(body.toString().toByteArray()) }
            val ok = c.responseCode in 200..299
            val raw = (if (ok) c.inputStream else c.errorStream).bufferedReader().readText()
            if (!ok) {
                val msg = try { JSONObject(raw).getJSONObject("error").getString("message") } catch (e: Exception) { raw }
                return Result(null, "HTTP ${c.responseCode}: ${msg.take(120)}")
            }
            val text = JSONObject(raw).getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
            val n = Regex("\\d+").find(text)?.value?.toInt()
            if (n == null) Result(null, "Unexpected reply: ${text.take(60)}") else Result(n)
        } catch (e: Exception) {
            Result(null, e.message ?: e.javaClass.simpleName)
        }
    }
}
