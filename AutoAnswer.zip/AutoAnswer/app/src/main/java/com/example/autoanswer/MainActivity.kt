package com.example.autoanswer

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.*

class MainActivity : Activity() {
    private lateinit var status: TextView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val prefs = getSharedPreferences("p", MODE_PRIVATE)
        val key = EditText(this).apply { hint = "Gemini API key"; setText(prefs.getString("key", "")) }
        val model = EditText(this).apply { hint = "Model"; setText(prefs.getString("model", "gemini-3.8-flash")) }
        status = TextView(this)
        fun btn(t: String, a: () -> Unit) = Button(this).apply { text = t; setOnClickListener { a() } }

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 96, 48, 48)
            addView(status)
            addView(key)
            addView(model)
            addView(btn("Save key & model") {
                prefs.edit().putString("key", key.text.toString().trim())
                    .putString("model", model.text.toString().trim()).apply()
                Toast.makeText(context, "Saved", Toast.LENGTH_SHORT).show()
                onResume()
            })
            addView(btn("1. Enable Accessibility service") {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            })
            addView(btn("2. Allow display over other apps") {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            })
            addView(btn("Show floating ON/OFF button") {
                AutoAnswerService.instance?.showOverlay()
                    ?: Toast.makeText(context, "Enable Accessibility first", Toast.LENGTH_SHORT).show()
            })
            addView(btn("Hide floating button (stops everything)") {
                AutoAnswerService.instance?.hideOverlay()
            })
        }
        setContentView(ScrollView(this).apply { addView(col) })
    }

    override fun onResume() {
        super.onResume()
        AutoAnswerService.instance?.showOverlay()      // button appears when you open the app
        val acc = AutoAnswerService.instance != null
        val ov = Settings.canDrawOverlays(this)
        val k = !getSharedPreferences("p", MODE_PRIVATE).getString("key", "").isNullOrBlank()
        fun mark(x: Boolean) = if (x) "OK" else "MISSING"
        status.text = "Accessibility: ${mark(acc)}\nOverlay: ${mark(ov)}\nAPI key: ${mark(k)}\n\n" +
            if (acc && ov) "Floating button is on screen. Open your quiz, then tap it to start (green = ON)."
            else "Finish the steps below first."
    }
}
